"""
模块B：项目管理表格录入辅助（通用版 v4.0）

本脚本主要用于：
  1. 生成符合各平台 API 规范的数据格式
  2. 将常用参数转换为正确格式（毫秒时间戳等）
  3. 从 config.yaml 读取表格平台配置

支持的平台：
  - tencent_doc：腾讯文档智能表格（通过 MCP）
  - feishu：飞书多维度表格（通过 API）
  - excel：本地 Excel 文件（通过 openpyxl）

实际写入由 AI 通过对应平台的 API/MCP 工具完成。
本脚本起辅助/格式转换作用。

用法：
  python3 add_to_doc.py \
    --action new \
    --client "曾应龙" \
    --opponent "东莞市荣港金属制品有限公司" \
    --cause "合伙" \
    --court "东莞市第一人民法院"
"""

import json
import argparse
import os
import yaml
from datetime import datetime

# =============================================
# 配置加载
# =============================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.yaml")


def load_config() -> dict:
    """加载 config.yaml 配置文件"""
    if not os.path.exists(CONFIG_PATH):
        raise FileNotFoundError(
            f"配置文件不存在：{CONFIG_PATH}\n"
            f"请先运行 python3 scripts/setup_wizard.py 完成初始化"
        )
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def get_sheet_config() -> tuple:
    """
    获取表格平台配置。
    返回：(platform, platform_config)
    """
    config = load_config()
    platform = config.get("sheet_platform", "")
    if not platform or platform == "none":
        raise ValueError(
            "表格平台未配置或设为'暂不配置'！\n"
            "请在 config.yaml 中配置 sheet_platform（tencent_doc/feishu/excel）"
        )

    if platform == "tencent_doc":
        td = config.get("tencent_doc", {})
        return platform, td
    elif platform == "feishu":
        fs = config.get("feishu", {})
        return platform, fs
    elif platform == "excel":
        ex = config.get("excel", {})
        return platform, ex
    else:
        raise ValueError(f"不支持的表格平台：{platform}")


# =============================================
# 字段格式辅助函数
# =============================================

def text_field(field_name: str, value: str) -> dict:
    """text类型字段（腾讯文档）"""
    return {
        "field": field_name,
        "text_value": {"items": [{"text": value, "type": "text"}]}
    }

def phone_field(field_name: str, value: str) -> dict:
    """phoneNumber类型字段（腾讯文档）"""
    return {"field": field_name, "string_value": value}

def select_field(field_name: str, option_id: str, option_text: str) -> dict:
    """
    singleSelect类型字段（腾讯文档），写入用 option_value，需 id + text
    ⚠️ option_id 必须由调用方传入（通过 list_fields 动态查询获取）
    """
    if not option_id:
        raise ValueError(
            f"option_id 未提供（字段={field_name}，选项={option_text}）\n"
            f"请先通过 smartsheet.list_fields 查询该字段的 option_id"
        )
    return {"field": field_name, "option_value": {"items": [{"id": option_id, "text": option_text}]}}

def datetime_field(field_name: str, dt: datetime) -> dict:
    """dateTime类型字段（毫秒时间戳）"""
    ts = str(int(dt.timestamp() * 1000))
    return {"field": field_name, "string_value": ts}

def parse_datetime(s: str) -> datetime:
    """
    解析日期字符串，支持格式：
    - "2026-06-08 09:00"
    - "2026-06-08"（默认 09:00）
    """
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    raise ValueError(f"日期格式不支持：{s}，请用 2026-06-08 或 2026-06-08 09:00")


# =============================================
# 腾讯文档：新案录入
# =============================================

def build_new_case_fields_tencent(info: dict) -> list:
    """
    生成新案录入的 field_values 列表（腾讯文档格式）。
    ⚠️ 只填有确定信息的字段，不确定的一律不加入列表。

    info 字段：
      project_name      项目名称
      client            委托人（全称）
      opponent          对方当事人（全称）
      cause             案由
      court             一审法院
      progress          当前进度（默认"待立案"）
      progress_id       当前进度 option_id
      stage             阶段（默认"一审"）
      stage_id          阶段 option_id
      preservation      保全情况（默认"无保全"）
      preservation_id   保全情况 option_id
      court_date        开庭日期（有传票才填）
      court_phone       一审联系方式
      case_no           一审案号（有受理通知书才填）

    ⚠️ 以下字段含义说明（极易填错！）：
      一审负责人 = 主审法官（不是律师！）
      经办人员   = 财产保全的法院经办人员（不是律师！）
      二审负责人 = 二审法官（不是律师！）
      执行法官/团队 = 执行法官或执行团队（不是律师！）
      → 这些字段只有在收到法院文书、知道具体法官/经办人姓名时才填，
        没有信息就留空，绝对不要填律师名字！
    """
    fields = []

    project_name = info.get("project_name") or \
        f"【诉】{info['client']}诉{info['opponent']}{info['cause']}"
    fields.append(text_field("项目名称", project_name))
    fields.append(text_field("委托人", info["client"]))
    fields.append(text_field("对方当事人", info["opponent"]))
    fields.append(text_field("案由", info["cause"]))

    if info.get("court"):
        fields.append(text_field("一审法院", info["court"]))

    progress = info.get("progress", "待立案")
    progress_id = info.get("progress_id", "")
    fields.append(select_field("当前进度", progress_id, progress))

    stage = info.get("stage", "一审")
    stage_id = info.get("stage_id", "")
    fields.append(select_field("阶段", stage_id, stage))

    preservation = info.get("preservation", "无保全")
    preservation_id = info.get("preservation_id", "")
    fields.append(select_field("保全情况", preservation_id, preservation))

    # 最新进展：简短描述案件当前状态，不重复已有字段信息
    latest_update = info.get("latest_update", "已委托，准备立案中")
    fields.append(text_field("最新进展", latest_update))

    if info.get("court_date"):
        dt = parse_datetime(info["court_date"])
        fields.append(datetime_field("开庭日期", dt))

    if info.get("court_phone"):
        fields.append(phone_field("一审联系方式", info["court_phone"]))

    if info.get("case_no"):
        fields.append(text_field("一审案号", info["case_no"]))

    # ⚠️ 一审负责人 = 主审法官，经办人员 = 保全法院经办人，都不是律师！
    # 只有收到法院文书、知道具体姓名时才填
    if info.get("court_person"):
        fields.append(text_field("一审负责人", info["court_person"]))
    if info.get("handling_person"):
        fields.append(text_field("经办人员", info["handling_person"]))

    return fields


# =============================================
# 飞书多维表格：新案录入
# =============================================

def build_new_case_fields_feishu(info: dict) -> dict:
    """
    生成新案录入的记录数据（飞书多维表格格式）。
    飞书格式：fields: {字段名: 值}
    - 文本字段：直接字符串
    - 单选字段：直接用选项文本字符串
    - 日期字段：Unix 时间戳（毫秒）
    不需要 option_id，飞书单选字段直接传文本即可匹配。

    飞书表格实际字段（按你的多维度表格结构）：
      案件管理(文本) / 案由(单选) / 当前进度(单选) / 最新进展(文本)
      开庭日期(日期) / 委托人(文本) / 对方当事人(文本) / 阶段(单选)
      结案方式(单选) / 保全情况(文本) / 一审法院(文本) / 一审案号(文本)
      一审负责人(文本) / 一审联系方式(文本) / 诉讼费缴费期限(日期)
      二审法院(文本) / 上诉期限届满日(日期) / 二审案号(文本) / 二审负责人(文本)
      案件生效日期(日期) / 执行案号(文本) / 执行法官/团队(文本) / 执行联系方式(文本)
      保全财产(文本) / 财保案号(文本) / 保全费缴费期限(日期)
      保全经办人员(文本) / 保全联系方式(文本) / 保全到期日(日期) / 保全情况备注(文本)

    ⚠️ 以下字段含义说明（极易填错！）：
      一审负责人   = 主审法官（不是律师！）
      二审负责人   = 二审法官（不是律师！）
      保全经办人员 = 财产保全的法院经办人员（不是律师！）
      执行法官/团队 = 执行法官或执行团队（不是律师！）
      → 这些字段只有在收到法院文书、知道具体法官/经办人姓名时才填，
        没有信息就留空，绝对不要填律师名字！
    """
    fields = {}

    # === 核心信息（新案必填）===
    project_name = info.get("project_name") or \
        f"【诉】{info['client']}诉{info['opponent']}{info['cause']}"
    fields["案件管理"] = project_name
    fields["委托人"] = info["client"]
    fields["对方当事人"] = info["opponent"]
    fields["案由"] = info["cause"]

    # === 一审信息 ===
    if info.get("court"):
        fields["一审法院"] = info["court"]
    if info.get("case_no"):
        fields["一审案号"] = info["case_no"]
    if info.get("court_person"):
        fields["一审负责人"] = info["court_person"]
    if info.get("court_phone"):
        fields["一审联系方式"] = info["court_phone"]
    if info.get("fee_deadline"):
        dt = parse_datetime(info["fee_deadline"])
        fields["诉讼费缴费期限"] = int(dt.timestamp() * 1000)
    if info.get("court_date"):
        dt = parse_datetime(info["court_date"])
        fields["开庭日期"] = int(dt.timestamp() * 1000)

    # === 状态 ===
    fields["当前进度"] = info.get("progress", "待立案")
    fields["阶段"] = info.get("stage", "一审")
    # 最新进展：简短描述案件当前状态，不重复已有字段信息
    fields["最新进展"] = info.get("latest_update", "已委托，准备立案中")

    # === 保全信息 ===
    if info.get("preservation"):
        fields["保全情况"] = info["preservation"]
    if info.get("preservation_property"):
        fields["保全财产"] = info["preservation_property"]
    if info.get("preservation_case_no"):
        fields["财保案号"] = info["preservation_case_no"]
    if info.get("preservation_fee_deadline"):
        dt = parse_datetime(info["preservation_fee_deadline"])
        fields["保全费缴费期限"] = int(dt.timestamp() * 1000)
    if info.get("preservation_person"):
        fields["保全经办人员"] = info["preservation_person"]
    if info.get("preservation_phone"):
        fields["保全联系方式"] = info["preservation_phone"]
    if info.get("preservation_expire_date"):
        dt = parse_datetime(info["preservation_expire_date"])
        fields["保全到期日"] = int(dt.timestamp() * 1000)
    if info.get("preservation_remark"):
        fields["保全情况备注"] = info["preservation_remark"]

    return fields


# =============================================
# 本地 Excel：新案录入
# =============================================

def build_new_case_fields_excel(info: dict) -> dict:
    """
    生成新案录入的行数据（Excel 格式：列名→值）。
    不需要 option_id，直接用文本值。
    """
    row = {}
    row["项目名称"] = info.get("project_name") or \
        f"【诉】{info['client']}诉{info['opponent']}{info['cause']}"
    row["委托人"] = info["client"]
    row["对方当事人"] = info["opponent"]
    row["案由"] = info["cause"]
    if info.get("court"):
        row["一审法院"] = info["court"]
    row["当前进度"] = info.get("progress", "待立案")
    row["阶段"] = info.get("stage", "一审")
    row["保全情况"] = info.get("preservation", "无保全")
    row["最新进展"] = info.get("latest_update", "已委托，准备立案中")
    if info.get("court_date"):
        row["开庭日期"] = info["court_date"]
    if info.get("court_phone"):
        row["一审联系方式"] = info["court_phone"]
    if info.get("case_no"):
        row["一审案号"] = info["case_no"]
    return row


# =============================================
# 进度更新辅助
# =============================================

def build_update_fields_tencent(updates: dict) -> list:
    """生成进度更新的 field_values 列表（腾讯文档格式）"""
    fields = []

    if updates.get("case_no"):
        fields.append(text_field("一审案号", updates["case_no"]))
    if updates.get("court_date"):
        dt = parse_datetime(updates["court_date"])
        fields.append(datetime_field("开庭日期", dt))
    if updates.get("court_phone"):
        fields.append(phone_field("一审联系方式", updates["court_phone"]))
    if updates.get("court_person"):
        fields.append(text_field("一审负责人", updates["court_person"]))
    if updates.get("progress") and updates.get("progress_id"):
        fields.append(select_field("当前进度", updates["progress_id"], updates["progress"]))
    if updates.get("closing_method") and updates.get("closing_method_id"):
        fields.append(select_field("结案方式", updates["closing_method_id"], updates["closing_method"]))
    if updates.get("effective_date"):
        dt = parse_datetime(updates["effective_date"])
        fields.append(datetime_field("案件生效日期", dt))

    return fields


def build_update_fields_excel(updates: dict) -> dict:
    """生成进度更新的行数据（Excel 格式：列名→值）"""
    row = {}
    if updates.get("case_no"):
        row["一审案号"] = updates["case_no"]
    if updates.get("court_date"):
        row["开庭日期"] = updates["court_date"]
    if updates.get("court_phone"):
        row["一审联系方式"] = updates["court_phone"]
    if updates.get("progress"):
        row["当前进度"] = updates["progress"]
    if updates.get("closing_method"):
        row["结案方式"] = updates["closing_method"]
    if updates.get("effective_date"):
        row["案件生效日期"] = updates["effective_date"]
    return row


def build_update_fields_feishu(updates: dict) -> dict:
    """生成进度更新的记录数据（飞书多维表格格式）
    
    支持的更新字段：
      一审案号 / 开庭日期 / 一审联系方式 / 一审负责人 / 当前进度 / 最新进展
      诉讼费缴费期限 / 结案方式 / 案件生效日期
      二审法院 / 二审案号 / 二审负责人 / 上诉期限届满日 / 上诉费缴费期限
      执行案号 / 执行法官/团队 / 执行联系方式
      保全相关字段

    ⚠️ "负责人"字段 = 法官，"经办人员"字段 = 法院经办人，都不是律师！
    """
    fields = {}
    
    # === 一审更新 ===
    if updates.get("case_no"):
        fields["一审案号"] = updates["case_no"]
    if updates.get("court_date"):
        dt = parse_datetime(updates["court_date"])
        fields["开庭日期"] = int(dt.timestamp() * 1000)
    if updates.get("court_phone"):
        fields["一审联系方式"] = updates["court_phone"]
    if updates.get("court_person"):
        fields["一审负责人"] = updates["court_person"]
    if updates.get("fee_deadline"):
        dt = parse_datetime(updates["fee_deadline"])
        fields["诉讼费缴费期限"] = int(dt.timestamp() * 1000)
    
    # === 状态更新 ===
    if updates.get("progress"):
        fields["当前进度"] = updates["progress"]
    if updates.get("latest_update"):
        fields["最新进展"] = updates["latest_update"]
    if updates.get("closing_method"):
        fields["结案方式"] = updates["closing_method"]
    if updates.get("effective_date"):
        dt = parse_datetime(updates["effective_date"])
        fields["案件生效日期"] = int(dt.timestamp() * 1000)
    
    # === 二审更新 ===
    if updates.get("court_2"):
        fields["二审法院"] = updates["court_2"]
    if updates.get("case_no_2"):
        fields["二审案号"] = updates["case_no_2"]
    if updates.get("court_person_2"):
        fields["二审负责人"] = updates["court_person_2"]
    if updates.get("appeal_deadline"):
        dt = parse_datetime(updates["appeal_deadline"])
        fields["上诉期限届满日"] = int(dt.timestamp() * 1000)
    if updates.get("appeal_fee_deadline"):
        dt = parse_datetime(updates["appeal_fee_deadline"])
        fields["上诉费缴费期限"] = int(dt.timestamp() * 1000)
    
    # === 执行更新 ===
    if updates.get("execution_case_no"):
        fields["执行案号"] = updates["execution_case_no"]
    if updates.get("execution_judge"):
        fields["执行法官/团队"] = updates["execution_judge"]
    if updates.get("execution_phone"):
        fields["执行联系方式"] = updates["execution_phone"]
    
    # === 保全更新 ===
    if updates.get("preservation_property"):
        fields["保全财产"] = updates["preservation_property"]
    if updates.get("preservation_case_no"):
        fields["财保案号"] = updates["preservation_case_no"]
    if updates.get("preservation_fee_deadline"):
        dt = parse_datetime(updates["preservation_fee_deadline"])
        fields["保全费缴费期限"] = int(dt.timestamp() * 1000)
    if updates.get("preservation_person"):
        fields["保全经办人员"] = updates["preservation_person"]
    if updates.get("preservation_phone"):
        fields["保全联系方式"] = updates["preservation_phone"]
    if updates.get("preservation_expire_date"):
        dt = parse_datetime(updates["preservation_expire_date"])
        fields["保全到期日"] = int(dt.timestamp() * 1000)
    if updates.get("preservation_remark"):
        fields["保全情况备注"] = updates["preservation_remark"]
    
    return fields


# =============================================
# CLI 入口
# =============================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="项目管理表格录入辅助（通用版）")
    parser.add_argument("--action",   default="new", choices=["new", "update"],
                        help="操作：new=新案录入，update=进度更新")

    # 通用参数
    parser.add_argument("--client",      help="委托人（全称）")
    parser.add_argument("--opponent",    help="对方当事人（全称）")
    parser.add_argument("--cause",       help="案由")
    parser.add_argument("--court",       help="一审法院")
    parser.add_argument("--progress",    default="待立案", help="当前进度")
    parser.add_argument("--court-date",  help="开庭日期（2026-06-08 09:00）")
    parser.add_argument("--court-phone", help="法院联系方式")
    parser.add_argument("--case-no",     help="一审案号")

    # 腾讯文档专用参数
    parser.add_argument("--progress-id",      default="", help="当前进度 option_id")
    parser.add_argument("--stage",            default="一审", help="阶段")
    parser.add_argument("--stage-id",         default="", help="阶段 option_id")
    parser.add_argument("--preservation",     default="无保全", help="保全情况")
    parser.add_argument("--preservation-id",  default="", help="保全情况 option_id")

    args = parser.parse_args()

    try:
        platform, platform_config = get_sheet_config()

        if args.action == "new":
            if not all([args.client, args.opponent, args.cause]):
                print("❌ 新案录入必须提供 --client --opponent --cause")
                exit(1)

            if platform == "tencent_doc":
                if not args.progress_id or not args.stage_id or not args.preservation_id:
                    print("⚠️ option_id 缺失！请先通过 smartsheet.list_fields 查询各 select 字段的 option_id")
                    exit(1)

                info = {
                    "client":          args.client,
                    "opponent":        args.opponent,
                    "cause":           args.cause,
                    "court":           args.court,
                    "progress":        args.progress,
                    "progress_id":     args.progress_id,
                    "stage":           args.stage,
                    "stage_id":        args.stage_id,
                    "preservation":    args.preservation,
                    "preservation_id": args.preservation_id,
                    "court_date":      args.court_date,
                    "court_phone":     args.court_phone,
                    "case_no":         args.case_no,
                }
                fields = build_new_case_fields_tencent(info)
                payload = [{"field_values": fields}]
                print("\n=== add_records 调用参数（腾讯文档）===")
                print(f"file_id: {platform_config.get('file_id', '')}")
                print(f"sheet_id: {platform_config.get('sheet_id', '')}")
                print(f"records: {json.dumps(payload, ensure_ascii=False)}")

            elif platform == "excel":
                info = {
                    "client":      args.client,
                    "opponent":    args.opponent,
                    "cause":       args.cause,
                    "court":       args.court,
                    "progress":    args.progress,
                    "stage":       args.stage,
                    "preservation":args.preservation,
                    "court_date":  args.court_date,
                    "court_phone": args.court_phone,
                    "case_no":     args.case_no,
                }
                row = build_new_case_fields_excel(info)
                print(f"\n=== Excel 新增行数据 ===")
                print(f"文件：{platform_config.get('file_path', '')}")
                print(json.dumps(row, ensure_ascii=False, indent=2))

            elif platform == "feishu":
                info = {
                    "client":          args.client,
                    "opponent":        args.opponent,
                    "cause":           args.cause,
                    "court":           args.court,
                    "progress":        args.progress,
                    "stage":           args.stage,
                    "preservation":    args.preservation,
                    "court_date":      args.court_date,
                    "court_phone":     args.court_phone,
                    "case_no":         args.case_no,
                }
                record_fields = build_new_case_fields_feishu(info)
                payload = {"fields": record_fields}
                print(f"\n=== 飞书多维表格 新增记录 ===")
                print(f"app_token: {platform_config.get('bitable_app_token', '')}")
                print(f"table_id: {platform_config.get('table_id', '')}")
                print(json.dumps(payload, ensure_ascii=False, indent=2))

        elif args.action == "update":
            updates = {
                "case_no":       args.case_no,
                "court_date":    args.court_date,
                "court_phone":   args.court_phone,
                "progress":      args.progress if args.progress != "待立案" else None,
                "progress_id":   args.progress_id if args.progress != "待立案" else None,
            }

            if platform == "tencent_doc":
                fields = build_update_fields_tencent({k: v for k, v in updates.items() if v})
                if not fields:
                    print("⚠️ 没有要更新的字段")
                else:
                    print("\n=== update_records 调用参数（腾讯文档）===")
                    print(json.dumps({"field_values": fields}, ensure_ascii=False, indent=2))

            elif platform == "excel":
                row = build_update_fields_excel({k: v for k, v in updates.items() if v})
                if not row:
                    print("⚠️ 没有要更新的字段")
                else:
                    print(f"\n=== Excel 更新数据 ===")
                    print(json.dumps(row, ensure_ascii=False, indent=2))

            elif platform == "feishu":
                feishu_fields = build_update_fields_feishu({k: v for k, v in updates.items() if v})
                if not feishu_fields:
                    print("⚠️ 没有要更新的字段")
                else:
                    print(f"\n=== 飞书多维表格 更新记录 ===")
                    print(f"app_token: {platform_config.get('bitable_app_token', '')}")
                    print(f"table_id: {platform_config.get('table_id', '')}")
                    print(json.dumps({"fields": feishu_fields}, ensure_ascii=False, indent=2))

    except (ValueError, FileNotFoundError) as e:
        print(f"❌ 错误：{e}")
        exit(1)
