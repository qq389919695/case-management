#!/usr/bin/env python3
"""
案件智能管理 - 初始化向导（通用版 v4.0）

交互式引导用户完成首次配置，包括：
  1. 项目文件夹结构（创建/指定）
  2. 项目管理表格平台选择 + 配置
  3. 文书模板配置
  4. 默认信息填写

用法：
  python3 ~/.workbuddy/skills/案件智能管理/scripts/setup_wizard.py
"""

import os
import sys
import json
import shutil
import yaml

# =============================================
# 常量
# =============================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.yaml")

# 标准文件夹结构 - 原告
PLAINTIFF_STRUCTURE = [
    "1.委托签约",
    "2.案件分析",
    "3.保全/3.1申请保全",
    "3.保全/3.2跟进保全",
    "3.保全/3.3保全文书",
    "4.一审【立案】/4.1起诉状与证据",
    "4.一审【立案】/4.2主体材料",
    "4.一审【立案】/4.3其他",
    "4.一审【立案】/4.4立案受理",
    "5.一审【庭前答辩】/5.1对方答辩",
    "5.一审【庭前答辩】/5.2传票通知",
    "6.一审【庭审庭后】/6.1开庭审理",
    "6.一审【庭审庭后】/6.2一审判决书",
    "7.二审阶段/7.1上诉文书",
    "7.二审阶段/7.2证据与庭审",
    "7.二审阶段/7.3二审法院文书",
    "8.执行/8.1申请执行",
    "8.执行/8.2执行法院文书",
    "9.归档",
]

# 标准文件夹结构 - 被告
DEFENDANT_STRUCTURE = [
    "1.委托签约",
    "2.案件分析",
    "3.保全/3.1申请保全",
    "3.保全/3.2跟进保全",
    "3.保全/3.3保全文书",
    "4.一审【应诉】/4.1原告起诉",
    "4.一审【应诉】/4.2受理与传票",
    "5.一审【答辩】/5.1答辩与证明",
    "5.一审【答辩】/5.2主体材料",
    "6.一审【庭审庭后】/6.1开庭审理",
    "6.一审【庭审庭后】/6.2一审判决书",
    "7.二审阶段/7.1上诉文书",
    "7.二审阶段/7.2证据与庭审",
    "7.二审阶段/7.3二审法院文书",
    "8.执行/8.1申请执行",
    "8.执行/8.2执行法院文书",
    "9.归档",
]


# =============================================
# 工具函数
# =============================================

def load_config() -> dict:
    """加载配置"""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


def save_config(config: dict):
    """保存配置"""
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        yaml.dump(config, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
    print(f"  ✅ 配置已保存到 {CONFIG_PATH}")


def ask(prompt: str, default: str = "") -> str:
    """交互式提问"""
    if default:
        full_prompt = f"  {prompt} [{default}]: "
    else:
        full_prompt = f"  {prompt}: "
    answer = input(full_prompt).strip()
    return answer if answer else default


def choose(prompt: str, options: list, default: str = "") -> str:
    """选择题"""
    print(f"\n  {prompt}")
    for i, opt in enumerate(options):
        label = opt.get("label", opt["key"])
        desc = opt.get("desc", "")
        marker = " ← 默认" if opt["key"] == default else ""
        print(f"    {i+1}. {label} — {desc}{marker}")
    while True:
        answer = input(f"  请选择 (1-{len(options)}): ").strip()
        if not answer and default:
            return default
        try:
            idx = int(answer) - 1
            if 0 <= idx < len(options):
                return options[idx]["key"]
        except ValueError:
            pass
        print("  ⚠️ 无效选择，请重试")


def confirm(prompt: str, default: bool = True) -> bool:
    """确认题"""
    hint = "Y/n" if default else "y/N"
    answer = input(f"  {prompt} ({hint}): ").strip().lower()
    if not answer:
        return default
    return answer in ("y", "yes", "是")


# =============================================
# 第一步：项目文件夹配置
# =============================================

def setup_case_root(config: dict) -> dict:
    """配置项目文件夹结构"""
    print("\n" + "=" * 60)
    print("  📁 第一步：项目文件夹配置")
    print("=" * 60)

    # 选择文件夹来源
    source = choose("你的项目文件夹模板结构是什么情况？", [
        {"key": "auto", "label": "A. 自动创建", "desc": "我还没有模板，帮我自动生成标准9级文件夹结构"},
        {"key": "existing", "label": "B. 已有模板", "desc": "我已有模板文件夹（原告/被告），直接指定路径"},
        {"key": "copy", "label": "C. 从现有案件复制", "desc": "我有一套已有的案件目录，把它作为模板"},
    ], default="auto")

    config["template_source"] = source

    # 项目根目录
    default_root = config.get("case_root", "")
    case_root = ask("诉讼项目根目录的绝对路径（案件文件夹将创建在此目录下）", default_root)
    if not case_root:
        print("  ⚠️ 根目录不能为空！")
        return setup_case_root(config)
    config["case_root"] = case_root

    if source == "auto":
        # 自动创建标准模板
        do_create = confirm(f"将在 {case_root} 下创建原告/被告模板文件夹，确认？")
        if do_create:
            create_standard_templates(case_root, config)
        else:
            print("  跳过自动创建，请稍后手动创建模板文件夹")

    elif source == "existing":
        # 指定已有模板名
        tp = ask("原告模板目录名", config.get("template_plaintiff", "【00模板】-【诉】民事诉讼（原告）"))
        td = ask("被告模板目录名", config.get("template_defendant", "【00模板】-【诉】民事诉讼（被告）"))
        config["template_plaintiff"] = tp
        config["template_defendant"] = td

        # 验证
        tp_path = os.path.join(case_root, tp)
        td_path = os.path.join(case_root, td)
        if not os.path.exists(tp_path):
            print(f"  ⚠️ 原告模板目录不存在：{tp_path}")
        if not os.path.exists(td_path):
            print(f"  ⚠️ 被告模板目录不存在：{td_path}")

    elif source == "copy":
        # 从现有案件复制
        ref_path = ask("请输入参考案件目录的绝对路径")
        if not os.path.exists(ref_path):
            print(f"  ⚠️ 路径不存在：{ref_path}")
            return setup_case_root(config)

        ref_name = os.path.basename(ref_path)
        print(f"  参考目录：{ref_name}")

        tp_name = ask("原告模板保存为", "【00模板】-【诉】民事诉讼（原告）")
        td_name = ask("被告模板保存为", "【00模板】-【诉】民事诉讼（被告）")

        tp_path = os.path.join(case_root, tp_name)
        td_path = os.path.join(case_root, td_name)

        # 询问是原告还是被告模板
        role = choose("这个参考案件是哪个角色的模板？", [
            {"key": "both", "label": "同时作为两者", "desc": "复制两份，分别作为原告和被告模板"},
            {"key": "plaintiff", "label": "原告模板", "desc": "只复制为原告模板"},
            {"key": "defendant", "label": "被告模板", "desc": "只复制为被告模板"},
        ])

        os.makedirs(case_root, exist_ok=True)
        if role in ("both", "plaintiff"):
            shutil.copytree(ref_path, tp_path)
            print(f"  ✅ 原告模板已创建：{tp_path}")
        if role in ("both", "defendant"):
            shutil.copytree(ref_path, td_path)
            print(f"  ✅ 被告模板已创建：{td_path}")

        config["template_plaintiff"] = tp_name
        config["template_defendant"] = td_name

    return config


def create_standard_templates(case_root: str, config: dict):
    """创建标准9级文件夹模板"""
    os.makedirs(case_root, exist_ok=True)

    tp_name = config.get("template_plaintiff", "【00模板】-【诉】民事诉讼（原告）")
    td_name = config.get("template_defendant", "【00模板】-【诉】民事诉讼（被告）")

    tp_path = os.path.join(case_root, tp_name)
    td_path = os.path.join(case_root, td_name)

    if os.path.exists(tp_path) or os.path.exists(td_path):
        print("  ⚠️ 模板目录已存在，跳过创建")
        return

    for structure, path in [(PLAINTIFF_STRUCTURE, tp_path), (DEFENDANT_STRUCTURE, td_path)]:
        os.makedirs(path, exist_ok=True)
        for d in structure:
            os.makedirs(os.path.join(path, d), exist_ok=True)
        print(f"  ✅ 已创建：{os.path.basename(path)}")

    # 在 1.委托签约 下放一个占位说明
    for path in [tp_path, td_path]:
        readme = os.path.join(path, "1.委托签约", "README-请将文书模板放在此目录.txt")
        with open(readme, "w", encoding="utf-8") as f:
            f.write("请将委托代理合同、授权委托书等 .docx 模板文件放在此目录下。\n")
            f.write("文件命名建议：\n")
            f.write("  00立案审批表.docx\n")
            f.write("  01-01委托代理合同.docx\n")
            f.write("  01-03授权委托书-民事.docx\n")
            f.write("  02公函（民事、行政、仲裁）.docx\n")


# =============================================
# 第二步：项目管理表格配置
# =============================================

def setup_sheet_platform(config: dict) -> dict:
    """配置项目管理表格平台"""
    print("\n" + "=" * 60)
    print("  📊 第二步：项目管理表格配置")
    print("=" * 60)

    platform = choose("你使用哪种表格来管理案件？", [
        {"key": "tencent_doc", "label": "A. 腾讯文档智能表格", "desc": "通过 MCP 直接读写腾讯文档智能表"},
        {"key": "feishu", "label": "B. 飞书多维度表格", "desc": "通过飞书 API 读写多维表格"},
        {"key": "excel", "label": "C. 本地 Excel", "desc": "读写本地 .xlsx 文件"},
        {"key": "none", "label": "D. 暂不配置", "desc": "跳过，后续再配置或手动录入"},
    ])

    config["sheet_platform"] = platform

    if platform == "tencent_doc":
        print("\n  📌 腾讯文档智能表格配置")
        print("  获取方式：打开智能表 → URL格式 https://docs.qq.com/smart-sheet/FILE_ID?tab=SHEET_ID")
        file_id = ask("FILE_ID", config.get("tencent_doc", {}).get("file_id", ""))
        sheet_id = ask("SHEET_ID", config.get("tencent_doc", {}).get("sheet_id", ""))
        config["tencent_doc"] = {"file_id": file_id, "sheet_id": sheet_id}

    elif platform == "feishu":
        print("\n  📌 飞书多维度表格配置")
        print("  需要飞书开放平台的应用凭证")
        app_id = ask("App ID")
        app_secret = ask("App Secret")
        bitable_app_token = ask("多维表格 App Token（URL中 /base/ 后面的部分）")
        table_id = ask("数据表 Table ID")
        config["feishu"] = {
            "app_id": app_id,
            "app_secret": app_secret,
            "bitable_app_token": bitable_app_token,
            "table_id": table_id,
        }

    elif platform == "excel":
        print("\n  📌 本地 Excel 配置")
        default_path = os.path.expanduser("~/Documents/诉讼案件汇总表.xlsx")
        file_path = ask("Excel 文件绝对路径", config.get("excel", {}).get("file_path", default_path))
        config["excel"] = {"file_path": file_path}

        if not os.path.exists(file_path):
            create = confirm(f"文件不存在，是否创建标准格式？ ({file_path})")
            if create:
                create_standard_excel(file_path)

    elif platform == "none":
        print("  ⏭️ 已跳过表格配置，后续可随时补充")

    return config


def create_standard_excel(file_path: str):
    """创建标准格式的 Excel 案件汇总表"""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill

        wb = Workbook()
        ws = wb.active
        ws.title = "诉讼案件汇总表"

        headers = [
            "项目名称", "委托人", "对方当事人", "案由", "一审法院",
            "当前进度", "阶段", "保全情况", "开庭日期", "一审联系方式",
            "一审案号", "最新进展", "备注", "经办人员",
            "二审法院", "二审案号", "二审联系方式",
            "结案方式", "案件生效日期",
            "财保案号", "保全到期日", "保全情况备注", "保全财产",
            "是否申请再审", "执行案号", "执行法官/团队", "执行联系方式",
        ]

        # 表头样式
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font = Font(bold=True, size=11, color="FFFFFF")

        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center")

        # 设置列宽
        for col in range(1, len(headers) + 1):
            ws.column_dimensions[ws.cell(row=1, column=col).column_letter].width = 18

        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        wb.save(file_path)
        print(f"  ✅ 已创建标准 Excel：{file_path}")

    except ImportError:
        print("  ⚠️ 需要安装 openpyxl：pip3 install openpyxl")
        print(f"  请手动创建 Excel 文件：{file_path}")


# =============================================
# 第三步：文书模板配置
# =============================================

def setup_template_files(config: dict) -> dict:
    """配置文书模板"""
    print("\n" + "=" * 60)
    print("  📝 第三步：文书模板配置")
    print("=" * 60)

    source = choose("你的文书模板（委托代理合同、授权委托书等）是什么情况？", [
        {"key": "none", "label": "A. 暂无模板", "desc": "手上没有模板文件，先跳过，后续再添加"},
        {"key": "generate", "label": "B. 帮我生成", "desc": "AI 根据文书类型自动生成标准 .docx 模板到模板目录"},
        {"key": "existing", "label": "C. 已有模板", "desc": "我有现成的模板文件，告诉你文件名"},
        {"key": "scan", "label": "D. 自动扫描", "desc": "我的模板目录里已有 .docx 文件，扫描后选择对应关系"},
    ], default="none")

    config["template_file_source"] = source

    if source == "none":
        print("  ⏭️ 已跳过文书模板配置，可随时补充")

    elif source == "generate":
        generate_template_files(config)

    elif source == "scan":
        scan_template_dir(config)

    elif source == "existing":
        custom_template_names(config)

    return config


def generate_template_files(config: dict):
    """AI 生成标准文书模板 .docx 文件"""
    case_root = config.get("case_root", "")
    template_name = config.get("template_plaintiff", "【00模板】-【诉】民事诉讼（原告）")
    template_dir = os.path.join(case_root, template_name, "1.委托签约")

    if not case_root:
        print("  ⚠️ 请先完成第一步的文件夹配置")
        return

    os.makedirs(template_dir, exist_ok=True)

    doc_types = {
        "立案审批表": "00立案审批表.docx",
        "委托代理合同": "01-01委托代理合同.docx",
        "授权委托书": "01-03授权委托书-民事.docx",
        "公函": "02公函（民事、行政、仲裁）.docx",
    }

    print(f"\n  将在以下目录生成模板：{template_dir}")
    print("  文书类型：")
    for i, (doc_type, filename) in enumerate(doc_types.items(), 1):
        print(f"    {i}. {doc_type} → {filename}")

    confirm = ask("确认生成以上模板？", "y")
    if confirm.lower() != "y":
        print("  ⏭️ 已跳过模板生成")
        return

    try:
        from docx import Document
        from docx.shared import Pt, Cm
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        print("  ⚠️ 需要安装 python-docx：pip3 install python-docx")
        print("  安装后重新运行向导即可生成模板")
        return

    # 各文书模板的内容模板
    templates_content = {
        "立案审批表": [
            ("立案审批表", True),
            ("", False),
            ("委托人：________________", False),
            ("对方当事人：________________", False),
            ("案由：________________", False),
            ("受理法院：________________", False),
            ("诉讼请求：________________", False),
            ("", False),
            ("经办律师：________________    日期：________________", False),
            ("审批意见：________________", False),
        ],
        "委托代理合同": [
            ("委托代理合同", True),
            ("", False),
            ("甲方（委托人）：________________", False),
            ("乙方（律师事务所）：________________", False),
            ("", False),
            ("鉴于甲方因 ____________________（案由）一案，委托乙方律师代理诉讼，双方经协商达成如下协议：", False),
            ("", False),
            ("一、委托事项", True),
            ("甲方委托乙方律师作为其与 ____________________（对方当事人）________________（案由）一案的诉讼代理人。", False),
            ("", False),
            ("二、代理权限", True),
            ("一般授权代理 / 特别授权代理（代为承认、放弃、变更诉讼请求，进行和解，提起反诉或者上诉等）。", False),
            ("", False),
            ("三、律师费及支付方式", True),
            ("________________", False),
            ("", False),
            ("四、其他约定", True),
            ("________________", False),
            ("", False),
            ("甲方（签章）：________________    日期：________________", False),
            ("乙方（签章）：________________    日期：________________", False),
        ],
        "授权委托书": [
            ("授权委托书", True),
            ("（民事用）", True),
            ("", False),
            ("委托人：________________", False),
            ("受托人：________________    律师执业证号：________________", False),
            ("工作单位：________________律师事务所", False),
            ("", False),
            ("现委托上述受托人在委托人与 ____________________（对方当事人）________________（案由）一案中，作为委托人的诉讼代理人。", False),
            ("", False),
            ("代理权限：□ 一般授权代理    □ 特别授权代理", False),
            ("特别授权范围：代为承认、放弃、变更诉讼请求，进行和解，提起反诉或者上诉。", False),
            ("", False),
            ("委托期限：自本委托书签署之日起至本案终结止。", False),
            ("", False),
            ("委托人（签章）：________________    日期：________________", False),
        ],
        "公函": [
            ("律 师 事 务 所 函", True),
            ("（民事、行政、仲裁）", True),
            ("", False),
            ("________________人民法院/仲裁委员会：", False),
            ("", False),
            ("本所接受 ____________________（委托人）的委托，指派 ____________________律师，担任 ____________________（对方当事人）________________（案由）一案的诉讼/仲裁代理人。", False),
            ("", False),
            ("特此函告", False),
            ("", False),
            ("________________律师事务所", False),
            ("____年____月____日", False),
        ],
    }

    generated = 0
    for doc_type, filename in doc_types.items():
        filepath = os.path.join(template_dir, filename)
        if os.path.exists(filepath):
            print(f"  ⏭️ {filename} 已存在，跳过")
            continue

        doc = Document()
        for text, is_heading in templates_content.get(doc_type, []):
            if is_heading:
                p = doc.add_heading(text, level=2)
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                p = doc.add_paragraph(text)
                p.paragraph_format.space_after = Pt(6)

        doc.save(filepath)
        print(f"  ✅ 已生成：{filename}")
        generated += 1

    if generated > 0:
        print(f"\n  ✅ 共生成 {generated} 个模板文件到 {template_dir}")
        print("  📌 这些是基础模板，你可以在此基础上自行完善内容")
    else:
        print("\n  ℹ️ 所有模板文件已存在，无需生成")


def scan_template_dir(config: dict):
    """扫描模板目录下的 .docx 文件"""
    case_root = config.get("case_root", "")
    template_name = config.get("template_plaintiff", "【00模板】-【诉】民事诉讼（原告）")
    template_dir = os.path.join(case_root, template_name, "1.委托签约")

    if not os.path.exists(template_dir):
        print(f"  ⚠️ 模板目录不存在：{template_dir}")
        print("  请先完成第一步的文件夹配置")
        return

    docx_files = [f for f in os.listdir(template_dir) if f.endswith(".docx")]
    if not docx_files:
        print(f"  ⚠️ 目录下没有 .docx 文件：{template_dir}")
        return

    print(f"\n  在 {template_dir} 下找到以下 .docx 文件：")
    for i, f in enumerate(docx_files, 1):
        print(f"    {i}. {f}")

    doc_types = ["立案审批表", "委托代理合同", "授权委托书", "公函"]
    mapping = {}

    for doc_type in doc_types:
        print(f"\n  📄 {doc_type} 对应哪个文件？")
        answer = ask(f"输入序号或文件名（留空跳过）")
        if not answer:
            continue
        try:
            idx = int(answer) - 1
            if 0 <= idx < len(docx_files):
                mapping[doc_type] = docx_files[idx]
            else:
                print("  ⚠️ 序号超出范围")
        except ValueError:
            # 用户直接输入了文件名
            if answer in docx_files:
                mapping[doc_type] = answer
            else:
                print(f"  ⚠️ 文件不存在：{answer}")

    if mapping:
        # 合并到 config，保留未指定的默认值
        current = config.get("template_files", {})
        current.update(mapping)
        config["template_files"] = current
        print(f"\n  ✅ 模板映射已更新：")
        for k, v in config["template_files"].items():
            print(f"    {k} → {v}")


def custom_template_names(config: dict):
    """手动指定模板文件名"""
    defaults = config.get("template_files", {
        "立案审批表": "00立案审批表.docx",
        "委托代理合同": "01-01委托代理合同.docx",
        "授权委托书": "01-03授权委托书-民事.docx",
        "公函": "02公函（民事、行政、仲裁）.docx",
    })

    print("  请填写各类文书对应的模板文件名（位于模板目录 1.委托签约/ 下）：")
    new_mapping = {}
    for doc_type, default_name in defaults.items():
        name = ask(f"{doc_type}", default_name)
        new_mapping[doc_type] = name

    config["template_files"] = new_mapping
    print(f"\n  ✅ 模板映射已更新")


# =============================================
# 第四步：默认信息
# =============================================

def setup_defaults(config: dict) -> dict:
    """配置默认信息"""
    print("\n" + "=" * 60)
    print("  👤 第四步：默认信息 + 提醒配置")
    print("=" * 60)

    lawyer = ask("默认经办律师姓名", config.get("default_lawyer", ""))
    config["default_lawyer"] = lawyer

    print("\n  提醒配置（回车使用默认值）：")
    config["court_remind_days_before"] = int(ask("开庭提醒提前天数", str(config.get("court_remind_days_before", 3))))
    config["fee_remind_days_before"] = int(ask("缴费提醒提前天数", str(config.get("fee_remind_days_before", 3))))
    config["appeal_period_days"] = int(ask("上诉期天数", str(config.get("appeal_period_days", 15))))
    config["fee_period_days"] = int(ask("缴费期限天数", str(config.get("fee_period_days", 7))))

    return config


# =============================================
# 汇总确认
# =============================================

def show_summary(config: dict):
    """展示配置汇总"""
    platform_labels = {
        "tencent_doc": "腾讯文档智能表格",
        "feishu": "飞书多维度表格",
        "excel": "本地 Excel",
        "none": "暂不配置",
    }

    print("\n" + "=" * 60)
    print("  📋 配置汇总")
    print("=" * 60)

    print(f"""
  📁 项目根目录：{config.get('case_root', '(未设置)')}
     模板来源：{config.get('template_source', '(未设置)')}
     原告模板：{config.get('template_plaintiff', '(默认)')}
     被告模板：{config.get('template_defendant', '(默认)')}

  📊 管理表格：{platform_labels.get(config.get('sheet_platform', ''), '(未设置)')}""")

    if config.get("sheet_platform") == "tencent_doc":
        td = config.get("tencent_doc", {})
        print(f"     FILE_ID：{td.get('file_id', '')}")
        print(f"     SHEET_ID：{td.get('sheet_id', '')}")
    elif config.get("sheet_platform") == "feishu":
        fs = config.get("feishu", {})
        print(f"     App Token：{fs.get('bitable_app_token', '')}")
        print(f"     Table ID：{fs.get('table_id', '')}")
    elif config.get("sheet_platform") == "excel":
        ex = config.get("excel", {})
        print(f"     文件路径：{ex.get('file_path', '')}")

    print(f"\n  📝 文书模板：{config.get('template_file_source', '(默认)')}")
    for k, v in config.get("template_files", {}).items():
        print(f"     {k} → {v}")

    print(f"""
  👤 默认律师：{config.get('default_lawyer', '(未设置)')}
  ⏰ 提醒配置：
     开庭前 {config.get('court_remind_days_before', 3)} 天提醒
     缴费前 {config.get('fee_remind_days_before', 3)} 天提醒
     上诉期 {config.get('appeal_period_days', 15)} 天
     缴费期 {config.get('fee_period_days', 7)} 天
""")


# =============================================
# 主入口
# =============================================

def main():
    print("""
╔══════════════════════════════════════════════╗
║   案件智能管理 - 初始化向导 v4.0             ║
║                                              ║
║   首次使用？跟着走就行，4步搞定配置           ║
╚══════════════════════════════════════════════╝
    """)

    config = load_config()

    # 依次四步
    config = setup_case_root(config)
    config = setup_sheet_platform(config)
    config = setup_template_files(config)
    config = setup_defaults(config)

    # 汇总确认
    show_summary(config)

    if confirm("\n  配置确认无误？保存并完成初始化"):
        from datetime import datetime
        config["setup_completed"] = True
        config["setup_date"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        save_config(config)
        print("\n  🎉 初始化完成！现在可以开始使用案件智能管理了。")
    else:
        print("\n  ⚠️ 配置未保存。如需重新配置，请再次运行此脚本。")


if __name__ == "__main__":
    main()
