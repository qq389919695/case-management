"""
诉讼委托签约四件套生成脚本（通用版 v4.0）
用法：python3 generate_docs.py [参数]

⚠️ 强制规则：
- --client 和 --opponent 传入简称（用于输出文件名）
- 模板目录中的所有文件（包括风险告知书、法定代表人身份证明等）**不得删除**
- 两种占位符替换模式：
  - simple：格式一（完整占位符在单个 <w:t> 节点）→ 直接 str.replace
  - three_run：格式二（委托代理合同，【XX】被拆成三个 <w:r> 节点）→ 正则识别三节点组合整体替换
- 所有路径、模板文件名、默认律师均从 config.yaml 读取
"""

import zipfile
import re
import os
import argparse
import yaml
from html import escape as xml_escape

# =============================================
# 配置加载
# =============================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.yaml")


def load_config() -> dict:
    """加载 config.yaml 配置文件"""
    if not os.path.exists(CONFIG_PATH):
        raise FileNotFoundError(
            f"配置文件不存在：{CONFIG_PATH}\n"
            f"请复制 config.yaml 并填写必要配置项"
        )
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# =============================================
# 格式一：简单字符串替换（完整占位符节点）
# =============================================

def replace_simple(content: str, replacements: dict) -> str:
    """直接字符串替换，适用于占位符在单个 <w:t> 内的情况"""
    for placeholder, value in replacements.items():
        safe_value = xml_escape(str(value))
        content = content.replace(placeholder, safe_value)
    return content


# =============================================
# 格式二：三节点模式替换（委托代理合同专用）
# =============================================

def replace_three_run(content: str, placeholder_name: str, value: str) -> str:
    """
    替换三节点格式的占位符：
      <w:r>...<w:t>【</w:t></w:r>
      <w:r>...<w:t>placeholder_name</w:t></w:r>
      <w:r>...<w:t>】</w:t></w:r>
    整体替换为第一个 run + 新文本（删除另外两个 run）
    """
    safe_value = xml_escape(str(value))

    left_run  = r'(<w:r\b[^>]*>(?:<w:rPr>(?:(?!</w:rPr>).)*</w:rPr>)?<w:t[^>]*>\u3010</w:t></w:r>)'
    inner_run = r'(?:<w:r\b[^>]*>(?:<w:rPr>(?:(?!</w:rPr>).)*</w:rPr>)?<w:t[^>]*>' + re.escape(placeholder_name) + r'</w:t></w:r>)'
    right_run = r'(?:<w:r\b[^>]*>(?:<w:rPr>(?:(?!</w:rPr>).)*</w:rPr>)?<w:t[^>]*>\u3011</w:t></w:r>)'

    pattern = left_run + inner_run + right_run

    def replacer(m):
        first_run = m.group(1)
        # 将第一个 run 的 <w:t>【</w:t> 改为 <w:t>新值</w:t>
        new_run = re.sub(r'<w:t[^>]*>\u3010</w:t>', f'<w:t>{safe_value}</w:t>', first_run)
        return new_run

    new_content, count = re.subn(pattern, replacer, content, flags=re.DOTALL)
    if count == 0:
        print(f"  ⚠️  三节点占位符未找到：【{placeholder_name}】")
    return new_content


def replace_contract(content: str, replacements: dict) -> str:
    """替换委托代理合同所有三节点占位符"""
    for name, value in replacements.items():
        content = replace_three_run(content, name, value)
    return content


# =============================================
# 通用 docx 处理
# =============================================

def process_docx(template_path: str, output_path: str, replacements: dict, mode: str = "simple"):
    """
    读取模板，替换占位符，写入输出路径。
    mode: 'simple' 或 'three_run'
    """
    if not os.path.exists(template_path):
        print(f"  ✗ 模板不存在：{template_path}")
        return False

    with zipfile.ZipFile(template_path, "r") as z:
        names = z.namelist()
        files = {name: z.read(name) for name in names}

    content = files["word/document.xml"].decode("utf-8")

    if mode == "simple":
        content = replace_simple(content, replacements)
    elif mode == "three_run":
        content = replace_contract(content, replacements)
    else:
        raise ValueError(f"未知模式: {mode}")

    files["word/document.xml"] = content.encode("utf-8")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as z:
        for name in names:
            z.writestr(name, files[name])

    print(f"  ✓ 生成：{os.path.basename(output_path)}")
    return True


# =============================================
# 主流程：生成四件套
# =============================================

def generate_all(case_dir: str, info: dict, config: dict = None):
    """
    info 字典字段：
      client        委托人简称
      client_full   委托人全称
      opponent      对方当事人简称
      opponent_full 对方当事人全称
      cause         案由
      court         管辖法院
      program       程序（一审/二审）
      fee_type      fixed / risk
      fee_amount    固定收费金额（fee_type=fixed时）
      risk_base     风险基础（fee_type=risk时）
      risk_ratio    风险比例（fee_type=risk时）
      target        涉案标的
      lawyer        经办律师
      role          plaintiff / defendant
      legal_rep     法定代表人（可选，默认 /）
      address       地址（可选，默认 /）
      phone         联系电话（可选，默认 /）
    """
    if config is None:
        config = load_config()

    root = config.get("case_root", "")
    role = info.get("role", "plaintiff")

    # 模板路径
    template_plaintiff_name = config.get("template_plaintiff", "【00模板】-【诉】民事诉讼（原告）")
    template_defendant_name = config.get("template_defendant", "【00模板】-【诉】民事诉讼（被告）")
    template_dir = os.path.join(root, template_plaintiff_name if role == "plaintiff" else template_defendant_name, "1.委托签约")

    output_dir = os.path.join(case_dir, "1.委托签约")
    client = info["client"]           # 简称，用于文件名
    client_full = info["client_full"] # 全称，用于文书正文
    opponent = info["opponent"]       # 简称，用于文件名
    opponent_full = info["opponent_full"]  # 全称，用于文书正文

    # 模板文件名映射（从配置读取）
    template_files = config.get("template_files", {
        "立案审批表": "00立案审批表.docx",
        "委托代理合同": "01-01委托代理合同-AI版.docx",
        "授权委托书": "01-03授权委托书-民事.docx",
        "公函": "02公函（民事、行政、仲裁）.docx",
    })

    # 默认律师（从配置读取）
    default_lawyer = config.get("default_lawyer", "")

    # 收费字段联动
    if info.get("fee_type") == "fixed":
        fee_amount   = info.get("fee_amount", "/")
        risk_base    = "/"
        risk_ratio   = "/"
        fixed_amount = info.get("fee_amount", "/")
        risk_base_la = "/"
    else:  # risk
        fee_amount   = "/"
        risk_base    = info.get("risk_base", "/")
        risk_ratio   = info.get("risk_ratio", "/")
        fixed_amount = "/"
        risk_base_la = info.get("risk_base", "/")

    fee_type_mark = "①" if info.get("fee_type") == "fixed" else "②"

    lawyer = info.get("lawyer") or default_lawyer or ""

    print(f"\n开始生成四件套（{client}，{role}）...")
    print(f"  模板目录：{template_dir}")
    print(f"  输出目录：{output_dir}\n")

    # ------------------------------------------
    # 1. 立案审批表（simple）
    # ------------------------------------------
    process_docx(
        template_path=os.path.join(template_dir, template_files["立案审批表"]),
        output_path=os.path.join(output_dir, f"立案审批表-{client}.docx"),
        replacements={
            "【委托人】":      client_full,
            "【法定代表人】":  info.get("legal_rep", "/"),
            "【地址】":        info.get("address", "/"),
            "【联系电话】":    info.get("phone", "/"),
            "【对方当事人】":  opponent_full,
            "【案由】":        info["cause"],
        "【涉案标的】":    str(info["target"]) if info["target"] else "/",
            "【固定收费数额】": fixed_amount,
            "【风险基础】":    risk_base_la,
            "【风险比例】":    risk_ratio,
        },
        mode="simple",
    )

    # ------------------------------------------
    # 2. 委托代理合同（three_run）
    # ------------------------------------------
    process_docx(
        template_path=os.path.join(template_dir, template_files["委托代理合同"]),
        output_path=os.path.join(output_dir, f"委托代理合同-{client}.docx"),
        replacements={
            "委托人":   client_full,
            "对方":     opponent_full,
            "案由":     info["cause"],
            "程序":     info["program"],
            "收费方式": fee_type_mark,
            "律师费金额": fee_amount,
            "基础费用": risk_base,
            "风险比例": risk_ratio,
            "程序期限": info["program"],
            "经办律师": lawyer,
        },
        mode="three_run",
    )

    # ------------------------------------------
    # 3. 授权委托书（simple）
    # ------------------------------------------
    process_docx(
        template_path=os.path.join(template_dir, template_files["授权委托书"]),
        output_path=os.path.join(output_dir, f"授权委托书-{client}.docx"),
        replacements={
            "【委托人】":      client_full,
            "【对方当事人】":  opponent_full,
            "【案由】":        info["cause"],
        },
        mode="simple",
    )

    # ------------------------------------------
    # 4. 公函（simple）
    # ------------------------------------------
    if role == "plaintiff":
        plaintiff_name = client_full
        defendant_name = opponent_full
    else:
        plaintiff_name = opponent_full
        defendant_name = client_full

    # ------------------------------------------
    # 4. 公函（simple）
    # ------------------------------------------
    if role == "plaintiff":
        plaintiff_name = client_full
        defendant_name = opponent_full
    else:
        plaintiff_name = opponent_full
        defendant_name = client_full

    process_docx(
        template_path=os.path.join(template_dir, template_files["公函"]),
        output_path=os.path.join(output_dir, f"公函-{client}.docx"),
        replacements={
            "【管辖法院】":  info["court"],
            "【原告】":      plaintiff_name,
            "【被告】":      defendant_name,
            "【案由】":      info["cause"],
            "【委托人】":    client_full,
            "【经办律师】":  lawyer,
            "【阶段】":      info["program"],
        },
        mode="simple",
    )

    # ------------------------------------------
    # 5. 自动清理输出目录中的模板文件
    # ------------------------------------------
    if config.get("clean_up_template_after_generate", False):
        import shutil
        deleted = []
        for key, fname in template_files.items():
            tpl_path = os.path.join(output_dir, fname)
            if os.path.exists(tpl_path):
                os.remove(tpl_path)
                deleted.append(fname)
        if deleted:
            print(f"\n🗑️  已清理 {len(deleted)} 个模板文件：")
            for f in deleted:
                print(f"   - {f}")

    print("\n✅ 四件套生成完成！")


# =============================================
# CLI 入口
# =============================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="诉讼委托签约四件套生成器（通用版）")
    parser.add_argument("--case-dir",    required=True,  help="案件目录绝对路径")
    parser.add_argument("--client",      required=True,  help="委托人简称（仅用于输出文件名）")
    parser.add_argument("--client-full", required=True,  help="委托人全称（用于文书正文）")
    parser.add_argument("--opponent",    required=True,  help="对方当事人简称（仅用于输出文件名）")
    parser.add_argument("--opponent-full", default=None, help="对方当事人全称（用于文书正文，自然人不填则同opponent）")
    parser.add_argument("--cause",       required=True,  help="案由（如：合伙、民间借贷）")
    parser.add_argument("--court",       default="",     help="管辖法院全称（可留空）")
    parser.add_argument("--program",     default="一审", help="程序（一审/二审）")
    parser.add_argument("--fee-type",    default="fixed", choices=["fixed","risk"], help="收费方式")
    parser.add_argument("--fee-amount",  default="/",    help="固定收费金额")
    parser.add_argument("--risk-base",   default="/",    help="风险代理基础费用")
    parser.add_argument("--risk-ratio",  default="/",    help="风险代理比例")
    parser.add_argument("--target",      default="",     help="涉案标的（元，可留空）")
    parser.add_argument("--lawyer",      default=None,   help="经办律师姓名（不填则使用 config.yaml 中的 default_lawyer）")
    parser.add_argument("--role",        default="plaintiff", choices=["plaintiff","defendant"], help="委托人身份")
    parser.add_argument("--legal-rep",   default="/",    help="法定代表人")
    parser.add_argument("--address",     default="/",    help="委托人地址")
    parser.add_argument("--phone",       default="/",    help="联系电话")

    args = parser.parse_args()

    config = load_config()

    info = {
        "client":        args.client,
        "client_full":   args.client_full,
        "opponent":      args.opponent,
        "opponent_full": args.opponent_full if args.opponent_full else args.opponent,
        "cause":         args.cause,
        "court":         args.court,
        "program":       args.program,
        "fee_type":      args.fee_type,
        "fee_amount":    args.fee_amount,
        "risk_base":     args.risk_base,
        "risk_ratio":    args.risk_ratio,
        "target":        args.target,
        "lawyer":        args.lawyer,
        "role":          args.role,
        "legal_rep":     args.legal_rep,
        "address":       args.address,
        "phone":         args.phone,
    }

    generate_all(args.case_dir, info, config)
