"""
模块A：案件文件夹创建脚本（通用版 v4.0）

用法：
  python3 create_case.py \
    --client "曾应龙" \
    --opponent "荣港公司" \
    --cause "合伙" \
    --role plaintiff

功能：
  1. 从 config.yaml 读取项目根目录和模板目录名
  2. 按命名规范生成案件目录名：【诉】XXX诉YYY案由
  3. 从模板（原告/被告）cp -r 复制完整文件夹架构
  4. 输出案件目录绝对路径

⚠️ 强制规则：
  - --client 和 --opponent 传入简称（用于文件夹名）
  - 公司名较长时，**必须先询问用户确认简称**，不得用全称传入
  - 腾讯文档"委托人"/"对方当事人"字段填全称（由 add_to_doc.py 单独处理）
  - 目标目录已存在时报错退出（不覆盖）
"""

import os
import shutil
import argparse
import yaml

# =============================================
# 配置加载
# =============================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.yaml")


def load_config() -> dict:
    """加载 config.yaml 配置文件"""
    if not os.path.exists(CONFIG_PATH):
        raise FileNotFoundError(
            f"配置文件不存在：{CONFIG_PATH}\n"
            f"请复制 config.yaml 并填写必要配置项（至少填写 case_root）"
        )
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# =============================================
# 主逻辑
# =============================================

def create_case(client: str, opponent: str, cause: str, role: str) -> str:
    """
    创建案件文件夹。

    返回：新建的案件目录绝对路径。
    """
    config = load_config()

    # 1. 读取配置
    root = config.get("case_root", "")
    if not root:
        raise ValueError(
            "config.yaml 中 case_root 未配置！\n"
            "请设置诉讼项目根目录路径，如：case_root: \"/Users/xxx/诉讼项目\""
        )

    template_plaintiff_name = config.get("template_plaintiff", "【00模板】-【诉】民事诉讼（原告）")
    template_defendant_name = config.get("template_defendant", "【00模板】-【诉】民事诉讼（被告）")

    template_plaintiff = os.path.join(root, template_plaintiff_name)
    template_defendant = os.path.join(root, template_defendant_name)

    # 2. 生成案件目录名
    case_name = f"【诉】{client}诉{opponent}{cause}"
    case_dir = os.path.join(root, case_name)

    # 3. 检查目标目录
    if os.path.exists(case_dir):
        raise FileExistsError(f"案件目录已存在，请勿重复创建：{case_dir}")

    # 4. 选择模板
    template_dir = template_plaintiff if role == "plaintiff" else template_defendant
    if not os.path.exists(template_dir):
        raise FileNotFoundError(f"模板目录不存在：{template_dir}")

    # 5. 复制模板
    print(f"\n📁 创建案件目录：{case_name}")
    print(f"   模板来源：{template_dir}")
    shutil.copytree(template_dir, case_dir)

    # 6. 列出一级文件夹
    entries = sorted(os.listdir(case_dir))
    print(f"\n   已创建子目录：")
    for entry in entries:
        full = os.path.join(case_dir, entry)
        if os.path.isdir(full):
            print(f"     ├── {entry}/")

    print(f"\n✅ 文件夹创建完成：{case_dir}\n")
    return case_dir


# =============================================
# CLI 入口
# =============================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="案件文件夹创建工具（模块A）")
    parser.add_argument("--client",   required=True, help="委托人简称（用于文件夹名，不是全称）")
    parser.add_argument("--opponent", required=True, help="对方当事人简称（用于文件夹名，不是全称）")
    parser.add_argument("--cause",    required=True, help="案由（如：合伙、民间借贷）")
    parser.add_argument("--role",     default="plaintiff",
                        choices=["plaintiff", "defendant"],
                        help="委托人身份（plaintiff=原告，defendant=被告）")

    args = parser.parse_args()

    try:
        case_dir = create_case(
            client=args.client,
            opponent=args.opponent,
            cause=args.cause,
            role=args.role,
        )
        # 输出路径供外部脚本捕获
        print(f"CASE_DIR={case_dir}")
    except FileExistsError as e:
        print(f"❌ {e}")
        exit(1)
    except (ValueError, FileNotFoundError) as e:
        print(f"❌ 配置错误：{e}")
        exit(1)
    except Exception as e:
        print(f"❌ 创建失败：{e}")
        exit(1)
